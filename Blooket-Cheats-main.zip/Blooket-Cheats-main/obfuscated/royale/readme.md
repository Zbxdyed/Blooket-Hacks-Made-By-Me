# Battle Royale Cheats

## [Intervals](intervals/)
Cheats that loop automatically

### [Auto Answer](intervals/autoAnswer.js)
Automatically answers questions for you


## [Auto Answer](autoAnswer.js)
Clicks the first correct answer